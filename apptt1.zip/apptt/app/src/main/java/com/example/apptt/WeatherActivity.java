package com.example.apptt;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class WeatherActivity extends AppCompatActivity {
    private TextView temperatureTextView;
    private TextView weatherDescriptionTextView;
    private TextView locationTextView;
    private TextView humidityTextView;
    private TextView windSpeedTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        // Initialize views
        temperatureTextView = findViewById(R.id.temperatureTextView);
        weatherDescriptionTextView = findViewById(R.id.weatherDescriptionTextView);
        locationTextView = findViewById(R.id.locationTextView);
        humidityTextView = findViewById(R.id.humidityTextView);
        windSpeedTextView = findViewById(R.id.windSpeedTextView);

        // Get weather data for a location
        getCoordinates("San Francisco");
    }

    private void getCoordinates(String locationName) {
        // Call Geocoding API to get latitude and longitude from location name
        Retrofit geocodingRetrofit = new Retrofit.Builder()
                .baseUrl("https://geocode.maps.co/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        GeocodingApiService geocodingService = geocodingRetrofit.create(GeocodingApiService.class);
        Call<GeocodingResponse> geocodingCall = geocodingService.getLocation(locationName, "6603ba18c4af6128928077imf01ab5d");

        geocodingCall.enqueue(new Callback<GeocodingResponse>() {
            @Override
            public void onResponse(Call<GeocodingResponse> call, Response<GeocodingResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    GeocodingResponse geocodingResponse = response.body();
                    GeocodingResponse.Location location = geocodingResponse.getResults().get(0).getGeometry().getLocation();
                    double latitude = location.getLatitude();
                    double longitude = location.getLongitude();
                    // Call fetchWeatherData with latitude and longitude
                    fetchWeatherData(latitude, longitude);
                } else {
                    // Handle unsuccessful response
                    showErrorMessage("Failed to fetch location data");
                }
            }

            @Override
            public void onFailure(Call<GeocodingResponse> call, Throwable t) {
                // Handle failure
                showErrorMessage("Failed to fetch location data: " + t.getMessage());
            }
        });
    }

    private void fetchWeatherData(double latitude, double longitude) {
        // Call OpenWeatherMap API to get weather data
        Retrofit weatherRetrofit = RetrofitClient.getClient("https://api.openweathermap.org/data/2.5/");
        WeatherApiService weatherService = weatherRetrofit.create(WeatherApiService.class);
        Call<WeatherData> weatherCall = weatherService.getWeatherByLocation(latitude, longitude, "ff6089b9ef7b0dc5b781b9501c1ff175");

        weatherCall.enqueue(new Callback<WeatherData>() {
            @Override
            public void onResponse(Call<WeatherData> call, Response<WeatherData> response) {
                if (response.isSuccessful() && response.body() != null) {
                    WeatherData weatherData = response.body();
                    WeatherData.Main main = weatherData.getMain();

                    if (main != null) {
                        double temperature = main.getTemp();
                        int humidity = main.getHumidity();

                        WeatherData.Weather[] weatherArray = weatherData.getWeather();
                        if (weatherArray != null && weatherArray.length > 0) {
                            String description = weatherArray[0].getDescription();
                            // Update UI components with weather data
                            temperatureTextView.setText("Temperature: " + temperature + " K"); // Convert temperature to Kelvin
                            weatherDescriptionTextView.setText("Weather description: " + description);
                            humidityTextView.setText("Humidity: " + humidity + "%");

                            // Additional weather information
                            locationTextView.setText("Location: " + weatherData.getName());
                            windSpeedTextView.setText("Wind Speed: " + weatherData.getWind().getSpeed() + " m/s");
                        } else {
                            showErrorMessage("No weather data available for the location");
                        }
                    }
                } else {
                    // Handle unsuccessful response
                    showErrorMessage("Failed to fetch weather data");
                }
            }

            @Override
            public void onFailure(Call<WeatherData> call, Throwable t) {
                // Handle failure
                showErrorMessage("Failed to fetch weather data: " + t.getMessage());
            }
        });
    }

    private void showErrorMessage(String message) {
        Toast.makeText(WeatherActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}
