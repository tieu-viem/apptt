package com.example.apptt;
public class CityData {
    private String name;
    private double lat;
    private double lon;
    private String country;
    private String state;

    // Add getters and setters here
}
